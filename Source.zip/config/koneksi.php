<?php 
$hostname 	= "localhost"; 
$username 	= "root";
$password 	= "";
$database 	= "simpeg";

$koneksi=mysqli_connect($hostname,$username,$password,$database);



?>